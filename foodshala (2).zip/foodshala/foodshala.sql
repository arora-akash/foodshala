-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2020 at 03:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodshala`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_name` varchar(30) NOT NULL,
  `c_mobile` bigint(10) NOT NULL,
  `c_pref` varchar(10) NOT NULL,
  `c_pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_name`, `c_mobile`, `c_pref`, `c_pass`) VALUES
('Akash', 7869453021, 'veg', 'patanahi'),
('Uday Singh', 9822415653, 'non-veg', 'uday'),
('Vaibhav Goyal', 9856233546, 'veg', 'kota');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `r_name` varchar(30) NOT NULL,
  `dish` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `pref` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `r_name`, `dish`, `price`, `pref`) VALUES
(19, 'Burger Street', 'Aloo Tikki Burger', 50, 'veg'),
(20, 'Burger Street', 'Cheese Burger', 80, 'veg'),
(21, 'Burger Street', 'Spicy Chicken Burger', 100, 'non-veg'),
(22, 'Mango Masala', 'Pav Bhaji', 120, 'veg'),
(23, 'Mango Masala', 'Chilli Chicken', 150, 'non-veg'),
(24, 'Mango Masala', 'Gulab Jamun', 60, 'veg'),
(25, 'Dosa Delight', 'Plain Dosa', 80, 'veg'),
(26, 'Dosa Delight', 'Masala Dosa', 100, 'veg'),
(27, 'Dosa Delight', 'Fried idli', 50, 'veg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `r_name` varchar(50) NOT NULL,
  `dish` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `c_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`r_name`, `dish`, `price`, `c_name`) VALUES
('Mango Masala', 'Pav Bhaji', 120, 'Akash'),
('Mango Masala', 'Gulab Jamun', 60, 'Akash'),
('Burger Street', 'Aloo Tikki Burger', 50, 'Vaibhav Goyal'),
('Dosa Delight', 'Fried idli', 50, 'Vaibhav Goyal'),
('Mango Masala', 'Chilli Chicken', 150, 'Vaibhav Goyal');

-- --------------------------------------------------------

--
-- Table structure for table `restraunt`
--

CREATE TABLE `restraunt` (
  `r_name` varchar(30) NOT NULL,
  `r_mobile` bigint(10) NOT NULL,
  `r_pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restraunt`
--

INSERT INTO `restraunt` (`r_name`, `r_mobile`, `r_pass`) VALUES
('Mango Masala', 1230456987, 'mko'),
('Burger Street', 8788965642, 'sejal'),
('Zaika Foods', 9833254732, 'fatima'),
('Dosa Delight', 9985766489, 'masala');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_mobile`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restraunt`
--
ALTER TABLE `restraunt`
  ADD PRIMARY KEY (`r_mobile`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
